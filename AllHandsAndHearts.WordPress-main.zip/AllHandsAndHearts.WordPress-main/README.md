# Blockprint WordPress Theme

## Installation

1. Create a new repository using this one as a template
1. Customize the theme colors in the following files:
   - `wp-content/themes/blockprint/theme.json`
   - `wp-content/themes/blockprint/admin/editor.js` (line 1)
   - `wp-content/themes/blockprint/assets/css/src/global.css`
1. Adjust the heading font sizes in `wp-content/themes/blockprint/assets/css/src/global.css`
1. Replace the default font stylesheet with your theme’s font stylesheet in `wp-content/themes/blockprint/functions.php`
1. In the theme root, open a terminal and run:

   ```bash
   npm install && npm run dev

## Included Blocks
1. Accordion
1. Accordions
2. Announcement Banner
1. Blog Post Card
1. Blog Posts List
1. Card
1. Cards
1. Contact
1. CTA Link
1. Featured Blog Post
1. Featured Blog Posts
1. Image Link Cards
1. Overlapping Content
1. Overlapping CTA Banner
1. Section Header
1. Simple CTA Banner
1. Simple Hero
1. Site Footer
1. Site Header
1. Spacer
1. Split Content
1. Split Hero
1. Stat List
1. Tab
1. Tabs
1. Two Column Content
1. Two Image Split Content
1. Value Proposition
1. Value Proposition Item

## Required Plugins

- [Advanced Custom Fields PRO](https://www.advancedcustomfields.com/pro/) (requires a license)

## Recommended Plugins

- [Autoptimize](https://wordpress.org/plugins/autoptimize/)
- [Block Visibility](https://wordpress.org/plugins/block-visibility/)
- [Custom Taxonomy Order](https://wordpress.org/plugins/custom-taxonomy-order-ne/)
- [Enable Media Replace](https://wordpress.org/plugins/enable-media-replace/)
- [FileBird](https://wordpress.org/plugins/filebird/)
- [Gravity Forms](https://www.gravityforms.com/) (requires a license)
- [Limit Login Attempts Reloaded](https://wordpress.org/plugins/limit-login-attempts-reloaded/)
- [SVG Support](https://wordpress.org/plugins/svg-support/)
- [Yoast Duplicate Post](https://wordpress.org/plugins/duplicate-post/)
- [Yoast SEO](https://wordpress.org/plugins/wordpress-seo/)
